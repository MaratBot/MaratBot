G30 Test: диагностическое приложение (только чтение).
1. Откройте папку в Android Studio (File > Open), дождитесь Gradle Sync.
2. Build > Build APK(s). Файл: app/build/outputs/apk/debug/app-debug.apk
Приложение НЕ собиралось и НЕ тестировалось на самокате.
