package com.example.g30

class Frame(val proto: Int, val target: Int, val cmd: Int, val index: Int, val data: ByteArray)

object Nb {
    const val CMD_READ = 0x01

    /** Protocol 1: 55 AA LEN TARGET CMD INDEX DATA.. CRC_LO CRC_HI (LEN = data+2) */
    fun buildP1(target: Int, cmd: Int, index: Int, data: ByteArray): ByteArray {
        val body = byteArrayOf((data.size + 2).toByte(), target.toByte(), cmd.toByte(), index.toByte()) + data
        val crc = body.sumOf { it.toInt() and 0xFF }.inv() and 0xFFFF
        return byteArrayOf(0x55, 0xAA.toByte()) + body + byteArrayOf((crc and 0xFF).toByte(), (crc shr 8).toByte())
    }

    /** Protocol 2 (per docs): 5A A5 LEN 3E TARGET CMD INDEX DATA.. CRC_LO CRC_HI (LEN = data) */
    fun buildP2(target: Int, cmd: Int, index: Int, data: ByteArray): ByteArray {
        val body = byteArrayOf(data.size.toByte(), 0x3E, target.toByte(), cmd.toByte(), index.toByte()) + data
        val crc = body.sumOf { it.toInt() and 0xFF }.inv() and 0x7FFF
        return byteArrayOf(0x5A, 0xA5.toByte()) + body + byteArrayOf((crc and 0xFF).toByte(), (crc shr 8).toByte())
    }

    fun readRequest(proto: Int, target: Int, index: Int, size: Int): ByteArray {
        val d = byteArrayOf(size.toByte())
        return if (proto == 1) buildP1(target, CMD_READ, index, d) else buildP2(target, CMD_READ, index, d)
    }

    /** Extracts complete frames from the accumulated buffer. */
    fun parse(buf: ArrayList<Byte>): List<Frame> {
        val out = ArrayList<Frame>()
        while (true) {
            var i = 0
            while (i + 1 < buf.size) {
                val a = buf[i].toInt() and 0xFF
                val b = buf[i + 1].toInt() and 0xFF
                if ((a == 0x55 && b == 0xAA) || (a == 0x5A && b == 0xA5)) break
                i++
            }
            repeat(i) { buf.removeAt(0) }
            if (buf.size < 3) break
            val p1 = (buf[0].toInt() and 0xFF) == 0x55
            val len = buf[2].toInt() and 0xFF
            if (p1 && len < 2) { repeat(2) { buf.removeAt(0) }; continue }
            val total = if (p1) len + 6 else len + 9
            if (buf.size < total) break
            val f = ByteArray(total) { buf[it] }
            repeat(total) { buf.removeAt(0) }
            fun u(i: Int) = f[i].toInt() and 0xFF
            out += if (p1) Frame(1, u(3), u(4), u(5), f.copyOfRange(6, 6 + len - 2))
            else Frame(2, u(4), u(5), u(6), f.copyOfRange(7, 7 + len))
        }
        return out
    }

    fun le(d: ByteArray): Long {
        var v = 0L
        for (i in d.indices.reversed()) v = (v shl 8) or (d[i].toLong() and 0xFF)
        return v
    }

    fun hex(b: ByteArray) = b.joinToString(" ") { "%02X".format(it) }

    /** Plaintext Encryption2 frame (before encryption): 5A A5 LEN 3E TARGET CMD INDEX DATA.. */
    fun buildEncPlain(target: Int, cmd: Int, index: Int, data: ByteArray): ByteArray {
        val len = data.size
        return byteArrayOf(0x5A, 0xA5.toByte(), len.toByte(), 0x3E, target.toByte(), cmd.toByte(), index.toByte()) + data
    }

    /** Extracts one full encrypted frame (5A A5 LEN .. +13) from the buffer once it has fully arrived. */
    fun extractEncFrame(buf: ArrayList<Byte>): ByteArray? {
        var i = 0
        while (i + 1 < buf.size) {
            val a = buf[i].toInt() and 0xFF; val b = buf[i + 1].toInt() and 0xFF
            if (a == 0x5A && b == 0xA5) break
            i++
        }
        repeat(i) { buf.removeAt(0) }
        if (buf.size < 3) return null
        val len = buf[2].toInt() and 0xFF
        val total = len + 13
        if (buf.size < total) return null
        val f = ByteArray(total) { buf[it] }
        repeat(total) { buf.removeAt(0) }
        return f
    }
}
