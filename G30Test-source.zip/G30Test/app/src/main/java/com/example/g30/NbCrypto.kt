package com.example.g30

import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/** Encryption2: AES-128 in a custom CTR-like mode with CBC-MAC. Ported from the open Segway-Ninebot protocol docs. */
object NbCrypto {

    fun aesEcb(key: ByteArray, block: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/ECB/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"))
        return c.doFinal(block)
    }

    fun deriveKey(key1: ByteArray, key2: ByteArray?): ByteArray {
        val k1 = ByteArray(16); System.arraycopy(key1, 0, k1, 0, minOf(16, key1.size))
        val k2 = ByteArray(16)
        if (key2 != null) System.arraycopy(key2, 0, k2, 0, minOf(16, key2.size))
        val sha1 = MessageDigest.getInstance("SHA-1").digest(k1 + k2)
        return sha1.copyOf(16)
    }

    fun buildNonce(counter: Int, auth: ByteArray): ByteArray {
        val n = ByteArray(13)
        n[0] = (counter shr 24).toByte(); n[1] = (counter shr 16).toByte()
        n[2] = (counter shr 8).toByte(); n[3] = counter.toByte()
        System.arraycopy(auth, 0, n, 4, 8)
        n[12] = 0
        return n
    }

    private fun xor(a: ByteArray, b: ByteArray, len: Int = a.size): ByteArray {
        val r = ByteArray(len)
        for (i in 0 until len) r[i] = (a[i].toInt() xor b[i].toInt()).toByte()
        return r
    }

    fun cbcMac(key: ByteArray, plaintext: ByteArray, nonce: ByteArray): ByteArray {
        val payloadLen = plaintext.size - 3
        val b0 = ByteArray(16)
        b0[0] = 0x59.toByte()
        System.arraycopy(nonce, 0, b0, 1, 13)
        b0[15] = payloadLen.toByte()
        var x = aesEcb(key, b0)
        val aad = ByteArray(16)
        System.arraycopy(plaintext, 0, aad, 0, 3)
        x = aesEcb(key, xor(x, aad))
        var off = 3
        while (off < plaintext.size) {
            val chunk = ByteArray(16)
            val n = minOf(16, plaintext.size - off)
            System.arraycopy(plaintext, off, chunk, 0, n)
            x = aesEcb(key, xor(x, chunk))
            off += 16
        }
        return x.copyOf(4)
    }

    fun encryptSn(key: ByteArray, auth: ByteArray, counter: Int, plaintext: ByteArray): ByteArray {
        val nonce = buildNonce(counter, auth)
        val rawTag = cbcMac(key, plaintext, nonce)
        val payload = plaintext.copyOfRange(3, plaintext.size)
        val ct = ByteArray(payload.size)
        var blockIdx = 1; var off = 0
        while (off < payload.size) {
            val aBlock = ByteArray(16)
            aBlock[0] = 0x01
            System.arraycopy(nonce, 0, aBlock, 1, 13)
            aBlock[15] = blockIdx.toByte()
            val ks = aesEcb(key, aBlock)
            val n = minOf(16, payload.size - off)
            for (j in 0 until n) ct[off + j] = (payload[off + j].toInt() xor ks[j].toInt()).toByte()
            off += 16; blockIdx++
        }
        val a0 = ByteArray(16); a0[0] = 0x01; System.arraycopy(nonce, 0, a0, 1, 13)
        val a0ks = aesEcb(key, a0)
        val encTag = xor(rawTag, a0ks, 4)
        val out = ByteArray(3 + ct.size + 4 + 2)
        System.arraycopy(plaintext, 0, out, 0, 3)
        System.arraycopy(ct, 0, out, 3, ct.size)
        System.arraycopy(encTag, 0, out, 3 + ct.size, 4)
        out[out.size - 2] = (counter shr 8).toByte()
        out[out.size - 1] = counter.toByte()
        return out
    }

    fun encryptNonSn(key: ByteArray, plaintext: ByteArray): ByteArray {
        val payload = plaintext.copyOfRange(3, plaintext.size)
        var checksum = 0
        for (b in payload) checksum += (b.toInt() and 0xFF)
        checksum = checksum.inv() and 0xFFFF
        val ks = aesEcb(key, ByteArray(16))
        val ct = ByteArray(payload.size)
        var off = 0
        while (off < payload.size) {
            val n = minOf(16, payload.size - off)
            for (j in 0 until n) ct[off + j] = (payload[off + j].toInt() xor ks[j].toInt()).toByte()
            off += 16
        }
        val out = ByteArray(3 + ct.size + 6)
        System.arraycopy(plaintext, 0, out, 0, 3)
        System.arraycopy(ct, 0, out, 3, ct.size)
        out[5 + ct.size] = (checksum and 0xFF).toByte()
        out[6 + ct.size] = (checksum shr 8).toByte()
        return out
    }

    /** Decrypts an incoming frame (5A A5 LEN + ciphertext + 4B MAC + 2B counter). Returns header+plaintext, or null. */
    fun decrypt(key: ByteArray, auth: ByteArray, raw: ByteArray): ByteArray? {
        if (raw.size < 9) return null
        val counter = ((raw[raw.size - 2].toInt() and 0xFF) shl 8) or (raw[raw.size - 1].toInt() and 0xFF)
        val header = raw.copyOfRange(0, 3)
        return try {
            if (counter > 0) {
                val nonce = buildNonce(counter, auth)
                val ctLen = raw.size - 3 - 4 - 2
                val ct = raw.copyOfRange(3, 3 + ctLen)
                val payload = ByteArray(ctLen)
                var blockIdx = 1; var off = 0
                while (off < ctLen) {
                    val aBlock = ByteArray(16); aBlock[0] = 0x01
                    System.arraycopy(nonce, 0, aBlock, 1, 13); aBlock[15] = blockIdx.toByte()
                    val ks = aesEcb(key, aBlock)
                    val n = minOf(16, ctLen - off)
                    for (j in 0 until n) payload[off + j] = (ct[off + j].toInt() xor ks[j].toInt()).toByte()
                    off += 16; blockIdx++
                }
                header + payload
            } else {
                val ctLen = raw.size - 3 - 6
                val ct = raw.copyOfRange(3, 3 + ctLen)
                val ks = aesEcb(key, ByteArray(16))
                val payload = ByteArray(ctLen)
                var off = 0
                while (off < ctLen) {
                    val n = minOf(16, ctLen - off)
                    for (j in 0 until n) payload[off + j] = (ct[off + j].toInt() xor ks[j].toInt()).toByte()
                    off += 16
                }
                header + payload
            }
        } catch (e: Exception) { null }
    }

    /** Replica of java.util.Random (48-bit LCG), needed to generate the session password the same way the official app does. */
    class JavaRandom(seed: Long) {
        private val mask = (1L shl 48) - 1
        private var seed: Long = (seed xor 0x5DEECE66DL) and mask
        private fun next(bits: Int): Int {
            seed = (seed * 0x5DEECE66DL + 0xBL) and mask
            return (seed ushr (48 - bits)).toInt()
        }
        fun nextBytes(n: Int): ByteArray {
            val out = ByteArray(n)
            var i = 0
            while (i < n) {
                var rnd = next(32)
                var k = minOf(n - i, 4)
                while (k-- > 0) { out[i++] = rnd.toByte(); rnd = rnd shr 8 }
            }
            return out
        }
    }

    fun generatePassword(authParam: ByteArray): ByteArray {
        val timeMs = System.currentTimeMillis()
        var seedValue = 0
        for (i in authParam.indices) {
            val b = authParam[i].toInt()
            val shift = (i % 8) * 8
            seedValue += (b shl (shift and 31))
        }
        val seed = timeMs + seedValue.toLong()
        val randomBytes = JavaRandom(seed).nextBytes(16)
        return MessageDigest.getInstance("SHA-256").digest(randomBytes).copyOf(16)
    }
}

/** State of one handshake/communication session with the scooter. */
class NbSession {
    var key: ByteArray? = null
    var auth: ByteArray? = null
    var serial: ByteArray? = null
    var password: ByteArray? = null
    var counter: Int = 0
}
