package com.example.g30

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }
}

@Composable
fun Screen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val main = remember { Handler(Looper.getMainLooper()) }
    val logs = remember { mutableStateListOf<String>() }
    val devices = remember { mutableStateListOf<Pair<BluetoothDevice, String>>() }
    val telemetry = remember { mutableStateMapOf<Int, String>() }
    val rx = remember { ArrayList<Byte>() }
    var state by remember { mutableStateOf("Не подключено") }
    var proto by remember { mutableIntStateOf(2) }
    var target by remember { mutableStateOf("01") }

    val ble = remember {
        BleClient(ctx, object : BleClient.Listener {
            override fun log(s: String) { main.post { logs.add(0, s) } }
            override fun state(s: String) { main.post { state = s } }
            override fun found(d: BluetoothDevice, name: String) {
                main.post {
                    if (name.isNotEmpty() && devices.none { it.first.address == d.address }) devices.add(d to name)
                }
            }
            override fun data(b: ByteArray) {
                main.post {
                    logs.add(0, "RX: " + Nb.hex(b))
                    b.forEach { rx.add(it) }
                    for (f in Nb.parse(rx)) {
                        logs.add(0, "Кадр: board=%02X cmd=%02X idx=%02X data=%s".format(f.target, f.cmd, f.index, Nb.hex(f.data)))
                        telemetry[f.index] = when {
                            f.index == 0x26 && f.data.size >= 2 -> "Скорость: %.1f км/ч".format(Nb.le(f.data) / 10.0)
                            f.index == 0xB5 && f.data.size >= 2 -> "Заряд: ${Nb.le(f.data)} %"
                            f.index == 0xB7 && f.data.size >= 4 -> "Пробег: %.3f км".format(Nb.le(f.data) / 1000.0)
                            f.index == 0x25 && f.data.size >= 2 -> "Запас хода: %.1f км".format(Nb.le(f.data) / 10.0)
                            else -> "reg %02X: %s".format(f.index, Nb.hex(f.data))
                        }
                    }
                }
            }
        })
    }

    val perms = if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) { devices.clear(); ble.scan() } else state = "Нет разрешений"
    }

    Column(Modifier.fillMaxSize().padding(12.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("G30 Test", fontSize = 22.sp)
        Text("Статус: $state")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { launcher.launch(perms) }) { Text("Поиск") }
            OutlinedButton(onClick = { ble.disconnect() }) { Text("Отключить") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = proto == 1, onClick = { proto = 1 }); Text("55 AA")
            Spacer(Modifier.width(12.dp))
            RadioButton(selected = proto == 2, onClick = { proto = 2 }); Text("5A A5")
            Spacer(Modifier.width(12.dp))
            OutlinedTextField(value = target, onValueChange = { target = it.take(2) }, label = { Text("Плата hex") },
                singleLine = true, modifier = Modifier.width(110.dp))
        }
        LazyColumn(Modifier.heightIn(max = 120.dp)) {
            items(devices) { (d, n) ->
                Text("$n  ${d.address}", Modifier.fillMaxWidth().clickable { ble.connect(d) }.padding(6.dp))
            }
        }
        Button(onClick = {
            val t = target.toIntOrNull(16) ?: 1
            scope.launch {
                for ((idx, size) in listOf(0x26 to 2, 0xB5 to 2, 0xB7 to 4, 0x25 to 2)) {
                    ble.send(Nb.readRequest(proto, t, idx, size)); delay(400)
                }
            }
        }) { Text("Прочитать: скорость, заряд, пробег, запас хода") }
        telemetry.toSortedMap().values.forEach { Text(it) }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f)) { items(logs) { Text(it, fontSize = 11.sp) } }
    }
}
