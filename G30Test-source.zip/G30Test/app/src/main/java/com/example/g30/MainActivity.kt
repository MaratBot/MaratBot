package com.example.g30

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Palette
private val Bg0 = Color(0xFF0A0812)
private val Bg1 = Color(0xFF140F24)
private val CardBg = Color(0xFF1C1730)
private val CardBg2 = Color(0xFF221B3B)
private val Stroke1 = Color(0x33A594FF)
private val AccentA = Color(0xFF8E7CF0)
private val AccentB = Color(0xFF5B4FE0)
private val TextDim = Color(0xFFA79FC7)
private val Green = Color(0xFF49D68A)
private val Amber = Color(0xFFE8A93C)
private val Red = Color(0xFFE2566A)

private val AccentGrad = Brush.horizontalGradient(listOf(AccentA, AccentB))
private val BgGrad = Brush.verticalGradient(listOf(Bg1, Bg0))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = AccentA, background = Bg0, surface = CardBg,
                    onSurface = Color.White, onBackground = Color.White,
                    secondaryContainer = CardBg2, onSecondaryContainer = Color.White
                )
            ) { Screen() }
        }
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    radius: Int = 26,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        shape = RoundedCornerShape(radius.dp),
        color = CardBg,
        border = BorderStroke(1.dp, Stroke1),
        modifier = modifier
    ) { Column(content = content) }
}

// На слабых устройствах (Android 5–6) тяжёлые бесконечные анимации отключаются ради плавности.
val LITE_MODE = Build.VERSION.SDK_INT < 24

@Composable
fun StatusChip(text: String, dot: Color, pulsing: Boolean = false) {
    val animatedAlpha = if (pulsing && !LITE_MODE) {
        val infinite = rememberInfiniteTransition(label = "pulse")
        val a by infinite.animateFloat(
            initialValue = 1f, targetValue = 0.3f,
            animationSpec = infiniteRepeatable(
                animation = tween<Float>(700, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulseAlpha"
        )
        a
    } else 1f
    Surface(shape = RoundedCornerShape(50), color = CardBg2, border = BorderStroke(1.dp, Stroke1)) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(dot.copy(alpha = animatedAlpha)))
            Spacer(Modifier.width(8.dp))
            Text(text, fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun SectionTitle(t: String) = Text(
    t.uppercase(), fontSize = 12.sp, letterSpacing = 1.5.sp,
    color = TextDim, fontWeight = FontWeight.SemiBold,
    modifier = Modifier.padding(top = 10.dp, start = 4.dp, bottom = 2.dp)
)

@Composable
fun IconBubble(emoji: String, size: Int = 44, bg: Color = CardBg2) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
        Text(emoji, fontSize = (size * 0.42).sp)
    }
}

@Composable
fun GradientButton(text: String, icon: String? = null, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val alpha = if (enabled) 1f else 0.4f
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.95f else 1f, tween(120), label = "btnScale")
    Box(
        modifier
            .scale(scale)
            .height(54.dp)
            .clip(RoundedCornerShape(27.dp))
            .background(AccentGrad)
            .clickable(enabled = enabled, interactionSource = interaction, indication = null) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.alpha(alpha)) {
            if (icon != null) { Text(icon, fontSize = 17.sp); Spacer(Modifier.width(8.dp)) }
            Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
    }
}

@Composable
fun GhostButton(text: String, icon: String? = null, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.95f else 1f, tween(120), label = "btnScale2")
    Box(
        modifier
            .scale(scale)
            .height(54.dp)
            .clip(RoundedCornerShape(27.dp))
            .background(CardBg2)
            .clickable(interactionSource = interaction, indication = null) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) { Text(icon, fontSize = 17.sp); Spacer(Modifier.width(8.dp)) }
            Text(text, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 16.sp)
        }
    }
}

@Composable
fun MetricRing(label: String, value: String, fraction: Float, ringColor: Color, modifier: Modifier = Modifier) {
    val animated by animateFloatAsState(targetValue = fraction.coerceIn(0f, 1f), animationSpec = tween(600), label = "ring")
    GlassCard(modifier) {
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(84.dp)) {
                    val stroke = 9.dp.toPx()
                    drawArc(color = Color(0x22FFFFFF), startAngle = -90f, sweepAngle = 360f, useCenter = false,
                        style = Stroke(stroke, cap = StrokeCap.Round))
                    drawArc(color = ringColor, startAngle = -90f, sweepAngle = 360f * animated, useCenter = false,
                        style = Stroke(stroke, cap = StrokeCap.Round))
                }
                Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(10.dp))
            Text(label, fontSize = 13.sp, color = TextDim)
        }
    }
}

@Composable
fun BigCard(emoji: String, title: String, value: String, modifier: Modifier = Modifier) {
    GlassCard(modifier) {
        Column(Modifier.padding(18.dp)) {
            IconBubble(emoji)
            Spacer(Modifier.height(12.dp))
            Text(title, color = TextDim, fontSize = 13.sp)
            Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

// Распознаёт Bluetooth-имена самокатов Segway / Ninebot / IoT-модулей по типичным префиксам.
fun isSegway(name: String): Boolean {
    val n = name.trim().uppercase()
    if (n.isEmpty()) return false
    // substring-признаки: встречаются где угодно в имени
    val contains = listOf("NINEBOT", "SEGWAY", "URENT", "SCOOTER")
    if (contains.any { n.contains(it) }) return true
    // prefix-признаки: имя начинается с этого
    val prefixes = listOf("SEGWAY", "NINEBOT", "NB", "N3M", "N4", "SNSC", "ES", "MAX", "G2", "G30", "GT", "F2", "E2", "DS-", "DS", "D-", "DYU", "IOT", "TST100", "TST")
    return prefixes.any { n.startsWith(it) }
}

// Грубая оценка расстояния по RSSI. Это приближение: мешают стены, тело, помехи — точность низкая.
fun estimateDistance(rssi: Int): String {
    if (rssi == 0) return "?"
    val txPower = -59.0 // типичный RSSI на 1 метре
    val ratio = (txPower - rssi) / 20.0
    val meters = Math.pow(10.0, ratio)
    return when {
        meters < 1.0 -> "< 1 м"
        meters < 10.0 -> "%.1f м".format(meters)
        else -> "%.0f м".format(meters)
    }
}

@Composable
fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = TextDim, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = AccentA, checkedThumbColor = Color.White))
    }
}

@Composable
fun SettingStepper(title: String, value: Int, min: Int, max: Int, step: Int, onChange: (Int) -> Unit) {
    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Box(Modifier.size(36.dp).clip(CircleShape).background(CardBg2).clickable { onChange((value - step).coerceAtLeast(min)) },
            contentAlignment = Alignment.Center) { Text("−", color = Color.White, fontSize = 20.sp) }
        Text("$value", color = AccentA, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.widthIn(min = 56.dp).padding(horizontal = 8.dp), textAlign = TextAlign.Center)
        Box(Modifier.size(36.dp).clip(CircleShape).background(CardBg2).clickable { onChange((value + step).coerceAtMost(max)) },
            contentAlignment = Alignment.Center) { Text("+", color = Color.White, fontSize = 20.sp) }
    }
}

@Composable
fun TileCard(emoji: String, title: String, modifier: Modifier = Modifier, iconBg: Color = CardBg2, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(22.dp), color = CardBg, border = BorderStroke(1.dp, Stroke1),
        modifier = modifier.heightIn(min = 120.dp).clickable { onClick() }
    ) {
        Column(Modifier.padding(18.dp)) {
            IconBubble(emoji, bg = iconBg)
            Spacer(Modifier.height(36.dp))
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
        }
    }
}

@Composable
fun Screen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val main = remember { Handler(Looper.getMainLooper()) }
    val logs = remember { mutableStateListOf<String>() }
    val devices = remember { mutableStateListOf<Triple<BluetoothDevice, String, Int>>() }
    val telemetry = remember { mutableStateMapOf<String, String>() }
    val rx = remember { ArrayList<Byte>() }
    var state by remember { mutableStateOf("Not connected") }
    var proto by remember { mutableIntStateOf(2) }
    var target by remember { mutableStateOf("01") }
    var tab by remember { mutableIntStateOf(0) }
    var encMode by remember { mutableStateOf(true) }
    var showAllBt by remember { mutableStateOf(false) }
    var debugLog by remember { mutableStateOf(true) }
    var autoReconnect by remember { mutableStateOf(false) }
    var maxAttempts by remember { mutableIntStateOf(20) }
    var reconnectDelay by remember { mutableIntStateOf(250) }
    var deviceType by remember { mutableIntStateOf(0) }
    var sessionState by remember { mutableStateOf("No session") }
    var deviceNameSel by remember { mutableStateOf("") }
    var customKey by remember { mutableStateOf("") }
    var autoTrying by remember { mutableStateOf(false) }
    val session = remember { NbSession() }
    val bleBox = remember { arrayOfNulls<BleClient>(1) }

    fun sendWire(w: ByteArray) { bleBox[0]?.send(w) }

    fun handleEncFrame(raw: ByteArray) {
        val key = session.key
        if (key == null) { logs.add(0, "No key to decrypt"); return }
        val plain = NbCrypto.decrypt(key, session.auth ?: ByteArray(16), raw)
        if (plain == null || plain.size < 6) { logs.add(0, "Failed to decrypt frame"); return }
        val board = plain[3].toInt() and 0xFF
        val cmd = plain[4].toInt() and 0xFF
        val index = plain[5].toInt() and 0xFF
        val data = plain.copyOfRange(6, plain.size)
        logs.add(0, "ENC RX: board=%02X cmd=%02X idx=%02X data=%s".format(board, cmd, index, Nb.hex(data)))
        when (cmd) {
            0x5B -> {
                if (data.size >= 30) {
                    val auth = data.copyOfRange(0, 16)
                    val serial = data.copyOfRange(16, 30)
                    session.auth = auth; session.serial = serial; session.counter = 1
                    sessionState = "Got auth+SN, sending password"
                    val pwd = NbCrypto.generatePassword(auth)
                    session.password = pwd
                    session.key = NbCrypto.deriveKey(deviceNameSel.toByteArray(), auth)
                    session.counter++
                    val p = Nb.buildEncPlain(0x04, 0x5C, 0x00, pwd)
                    sendWire(NbCrypto.encryptSn(session.key!!, auth, session.counter, p))
                } else { sessionState = "PRE_COMM: unexpected response"; logs.add(0, "Looks like an echo or wrong format") }
            }
            0x5C -> {
                if (index == 1) {
                    sessionState = "Password accepted, authorizing…"
                    val auth = session.auth!!
                    session.key = NbCrypto.deriveKey(session.password!!, auth)
                    session.counter++
                    val p = Nb.buildEncPlain(0x04, 0x5D, 0x00, session.serial!!)
                    sendWire(NbCrypto.encryptSn(session.key!!, auth, session.counter, p))
                } else {
                    sessionState = "Press the button on the scooter and retry"
                }
            }
            0x5D -> {
                sessionState = if (index == 1) "Connected (COMM)" else "Authorization failed"
            }
            else -> {
                when {
                    index == 0x26 && data.size >= 2 -> telemetry["speed"] = "%.1f".format(Nb.le(data) / 10.0)
                    index == 0xB5 && data.size >= 2 -> telemetry["battery"] = "${Nb.le(data)}"
                    index == 0xB7 && data.size >= 4 -> telemetry["odo"] = "%.3f km".format(Nb.le(data) / 1000.0)
                    index == 0x25 && data.size >= 2 -> telemetry["range"] = "%.1f km".format(Nb.le(data) / 10.0)
                }
            }
        }
    }

    fun sendEncRead(targetBoard: Int, index: Int, size: Int) {
        val key = session.key; val auth = session.auth
        if (key == null || auth == null) { logs.add(0, "Do the handshake first"); return }
        session.counter++
        val p = Nb.buildEncPlain(targetBoard, 0x01, index, byteArrayOf(size.toByte()))
        sendWire(NbCrypto.encryptSn(key, auth, session.counter, p))
    }

    fun fireCmd(name: String, cmd: Int, index: Int, data: ByteArray) {
        val t = target.toIntOrNull(16) ?: 1
        logs.add(0, "CMD $name: board=0x%02X cmd=0x%02X idx=0x%02X data=%s".format(t, cmd, index, Nb.hex(data)))
        if (encMode) {
            val key = session.key; val auth = session.auth
            if (key == null || auth == null) { logs.add(0, "No session — do the handshake first"); return }
            session.counter++
            sendWire(NbCrypto.encryptSn(key, auth, session.counter, Nb.buildEncPlain(t, cmd, index, data)))
        } else {
            sendWire(if (proto == 1) Nb.buildP1(t, cmd, index, data) else Nb.buildP2(t, cmd, index, data))
        }
    }

    fun startHandshakeWith(keySource: ByteArray, label: String) {
        session.auth = null; session.serial = null; session.password = null; session.counter = 0
        sessionState = "PRE_COMM ($label)…"
        val key = NbCrypto.deriveKey(keySource, null)
        session.key = key
        rx.clear()
        val p = Nb.buildEncPlain(0x04, 0x5B, 0x00, ByteArray(0))
        sendWire(NbCrypto.encryptNonSn(key, p))
    }

    fun doHandshake() {
        if (deviceNameSel.isEmpty()) { logs.add(0, "Connect to the scooter first"); return }
        val src = if (customKey.isNotBlank()) customKey.toByteArray() else deviceNameSel.toByteArray()
        val label = if (customKey.isNotBlank()) customKey else "name"
        startHandshakeWith(src, label)
    }

    // Перебор всех известных ключей: имя устройства + сохранённые BLE-ключи.
    fun autoHandshake() {
        if (deviceNameSel.isEmpty()) { logs.add(0, "Connect to the scooter first"); return }
        val candidates = listOf(
            deviceNameSel to "name",
            "w4S3Hqn5" to "key1",
            "78Hkw9NN" to "key2",
            "4BkNWi77" to "key3",
            "88F4A2B9" to "key4",
            "Ulb8omSq" to "urent1",
            "9wYGaWn6" to "urent2",
            "S9oqBJM0" to "urent3",
            "90AB43D1" to "voi1"
        )
        autoTrying = true
        scope.launch {
            for ((value, label) in candidates) {
                if (!autoTrying) break
                if (sessionState == "Connected (COMM)") break
                logs.add(0, "Auto-handshake: trying key '$label'")
                startHandshakeWith(value.toByteArray(), label)
                // ждём до 2.5 с, проверяя, не вышли ли на связь
                var waited = 0
                while (waited < 2500 && autoTrying) {
                    delay(250); waited += 250
                    if (sessionState == "Connected (COMM)") break
                    if (sessionState.startsWith("Password accepted") || sessionState.startsWith("Got auth")) break
                }
                if (sessionState == "Connected (COMM)") { logs.add(0, "Auto-handshake: success with '$label'"); break }
            }
            autoTrying = false
        }
    }

    val ble = remember {
        BleClient(ctx, object : BleClient.Listener {
            override fun log(s: String) { main.post { logs.add(0, s) } }
            override fun state(s: String) { main.post { state = s } }
            override fun found(d: BluetoothDevice, name: String, rssi: Int) {
                main.post {
                    if (name.isEmpty()) return@post
                    val i = devices.indexOfFirst { it.first.address == d.address }
                    if (i >= 0) devices[i] = Triple(d, name, rssi)
                    else devices.add(Triple(d, name, rssi))
                }
            }
            override fun data(b: ByteArray) {
                main.post {
                    if (debugLog) logs.add(0, "RX: " + Nb.hex(b))
                    b.forEach { rx.add(it) }
                    if (encMode) {
                        while (true) { val f = Nb.extractEncFrame(rx) ?: break; handleEncFrame(f) }
                    } else {
                        for (f in Nb.parse(rx)) {
                            logs.add(0, "Frame: board=%02X cmd=%02X idx=%02X data=%s".format(f.target, f.cmd, f.index, Nb.hex(f.data)))
                            when {
                                f.index == 0x26 && f.data.size >= 2 -> telemetry["speed"] = "%.1f".format(Nb.le(f.data) / 10.0)
                                f.index == 0xB5 && f.data.size >= 2 -> telemetry["battery"] = "${Nb.le(f.data)}"
                                f.index == 0xB7 && f.data.size >= 4 -> telemetry["odo"] = "%.3f km".format(Nb.le(f.data) / 1000.0)
                                f.index == 0x25 && f.data.size >= 2 -> telemetry["range"] = "%.1f km".format(Nb.le(f.data) / 10.0)
                            }
                        }
                    }
                }
            }
        })
    }
    bleBox[0] = ble

    val perms = if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) { devices.clear(); ble.scan() } else state = "No permissions"
    }

    fun poll() {
        val t = target.toIntOrNull(16) ?: 1
        scope.launch {
            for ((idx, size) in listOf(0x26 to 2, 0xB5 to 2, 0xB7 to 4, 0x25 to 2)) {
                if (encMode) sendEncRead(t, idx, size) else ble.send(Nb.readRequest(proto, t, idx, size))
                delay(500)
            }
        }
    }

    val connected = state == "Connected"
    val comm = sessionState == "Connected (COMM)"

    Scaffold(
        containerColor = Bg0,
        bottomBar = {
            Surface(color = Bg1, tonalElevation = 0.dp) {
                NavigationBar(containerColor = Color.Transparent) {
                    val items = listOf("⚡" to "Control", "🏎" to "Telemetry", "⌨" to "Console", "⚙️" to "Settings")
                    items.forEachIndexed { i, (ic, label) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Text(ic, fontSize = 20.sp) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AccentA, selectedTextColor = AccentA,
                                unselectedIconColor = TextDim, unselectedTextColor = TextDim,
                                indicatorColor = CardBg2
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .background(BgGrad)
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 16.dp)
        ) {
            Row(Modifier.padding(top = 14.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBubble("🛴", size = 40, bg = CardBg2)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("MaratBot", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(
                        when (tab) { 0 -> "Connection and control"; 1 -> "Real-time telemetry"; else -> "Raw log and commands" },
                        fontSize = 12.sp, color = TextDim
                    )
                }
            }

            AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    if (LITE_MODE) {
                        fadeIn(tween(120)) togetherWith fadeOut(tween(90))
                    } else {
                        val dir = if (targetState > initialState) 1 else -1
                        (slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { it * dir } + fadeIn(tween(220))) togetherWith
                            (slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { -it * dir } + fadeOut(tween(160)))
                    }
                },
                label = "tabSwitch",
                modifier = Modifier.fillMaxSize()
            ) { targetTab ->
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
                when (targetTab) {
                    0 -> {
                        item {
                            GlassCard {
                                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        StatusChip(state, if (connected) Green else Amber, pulsing = !connected && state != "Not connected")
                                        StatusChip(sessionState, if (comm) Green else if (sessionState == "No session") TextDim else Amber, pulsing = sessionState != "No session" && !comm)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        GradientButton("Scan", "🔍", modifier = Modifier.weight(1f)) { launcher.launch(perms) }
                                        GhostButton("Disconnect", "✕", modifier = Modifier.weight(1f)) { ble.disconnect(); sessionState = "No session" }
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Switch(
                                            checked = encMode, onCheckedChange = { encMode = it },
                                            colors = SwitchDefaults.colors(checkedTrackColor = AccentA, checkedThumbColor = Color.White)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text("AES encryption (G2)", fontSize = 13.sp, color = TextDim)
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Switch(
                                            checked = showAllBt, onCheckedChange = { showAllBt = it },
                                            colors = SwitchDefaults.colors(checkedTrackColor = AccentA, checkedThumbColor = Color.White)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(if (showAllBt) "Show all Bluetooth" else "Segway devices only", fontSize = 13.sp, color = TextDim)
                                    }
                                    GradientButton("Handshake", "🤝", enabled = connected, modifier = Modifier.fillMaxWidth()) { autoHandshake() }
                                    if (autoTrying) {
                                        Text("Trying keys…", fontSize = 11.sp, color = TextDim)
                                    }
                                }
                            }
                        }
                        val visibleDevices = (if (showAllBt) devices else devices.filter { isSegway(it.second) })
                        if (visibleDevices.isNotEmpty() && !connected) {
                            item { SectionTitle("Found devices") }
                            val sorted = visibleDevices.sortedWith(compareByDescending<Triple<BluetoothDevice, String, Int>> { isSegway(it.second) }.thenByDescending { it.third })
                            items(sorted, key = { it.first.address }) { (d, n, rssi) ->
                                var shown by remember { mutableStateOf(false) }
                                LaunchedEffect(Unit) { shown = true }
                                val a by animateFloatAsState(if (shown) 1f else 0f, tween(260), label = "devFade")
                                val segway = isSegway(n)
                                // Качество и дистанция по RSSI
                                val quality = when {
                                    rssi >= -60 -> "Отличный" to Green
                                    rssi >= -72 -> "Хороший" to Green
                                    rssi >= -83 -> "Средний" to Amber
                                    else -> "Слабый" to Red
                                }
                                val distance = estimateDistance(rssi)
                                Surface(
                                    shape = RoundedCornerShape(18.dp), color = CardBg,
                                    border = BorderStroke(1.dp, if (segway) AccentA else Stroke1),
                                    modifier = Modifier.fillMaxWidth().alpha(a).clickable { deviceNameSel = n; ble.connect(d) }
                                ) {
                                    Column(Modifier.padding(16.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            IconBubble(if (segway) "🛴" else "📶", 36, bg = if (segway) AccentA.copy(alpha = 0.22f) else CardBg2)
                                            Spacer(Modifier.width(10.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(n, color = Color.White, fontWeight = FontWeight.Medium)
                                                Text(d.address, color = TextDim, fontSize = 12.sp)
                                            }
                                            if (segway) {
                                                Surface(shape = RoundedCornerShape(50), color = AccentA.copy(alpha = 0.25f),
                                                    border = BorderStroke(1.dp, AccentA)) {
                                                    Text("Segway", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.SemiBold,
                                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                                                }
                                            }
                                        }
                                        Spacer(Modifier.height(10.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(Modifier.size(8.dp).clip(CircleShape).background(quality.second))
                                            Spacer(Modifier.width(6.dp))
                                            Text("${quality.first} · ${rssi} dBm", fontSize = 12.sp, color = quality.second)
                                            Spacer(Modifier.weight(1f))
                                            Text("≈ $distance", fontSize = 12.sp, color = TextDim)
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                GradientButton("Unlock", "🔓", modifier = Modifier.weight(1f)) { fireCmd("Unlock", 0x03, 0x05, byteArrayOf(0x01)) }
                                GhostButton("Lock", "🔒", modifier = Modifier.weight(1f)) { fireCmd("Lock", 0x03, 0x15, byteArrayOf(0x01)) }
                            }
                        }
                        item { SectionTitle("Accessories") }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                TileCard("🔋", "Battery cover", Modifier.weight(1f)) { fireCmd("Battery cover", 0x03, 0xC0, byteArrayOf(0x01)) }
                                TileCard("💡", "Light on", Modifier.weight(1f), iconBg = Color(0xFF3A3020)) { fireCmd("Light on", 0x03, 0x61, byteArrayOf(0x01)) }
                            }
                        }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                TileCard("🌙", "Light off", Modifier.weight(1f)) { fireCmd("Light off", 0x03, 0x61, byteArrayOf(0x00)) }
                                TileCard("📳", "Find / horn", Modifier.weight(1f)) { fireCmd("Find/horn", 0x03, 0xA2, byteArrayOf(0x02)) }
                            }
                        }
                        item { SectionTitle("Sounds") }
                        item {
                            val sounds = listOf(
                                Triple("🔊", "Notify", 0x01),
                                Triple("🔔", "Find scooter", 0x02),
                                Triple("🎵", "Horn", 0x03),
                                Triple("📢", "fire rap", 0x04)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                sounds.forEach { (emoji, name, value) ->
                                    Surface(
                                        shape = RoundedCornerShape(18.dp), color = CardBg, border = BorderStroke(1.dp, Stroke1),
                                        modifier = Modifier.weight(1f).clickable { fireCmd("Sound $name", 0x03, 0xA2, byteArrayOf(value.toByte())) }
                                    ) {
                                        Column(Modifier.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                            IconBubble(emoji, 36)
                                            Spacer(Modifier.height(8.dp))
                                            Text(name, fontSize = 11.sp, color = TextDim, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                        item { SectionTitle("Light colour") }
                        item {
                            val colours = listOf(
                                Triple("Red", Color(0xFFE2566A), Triple(0xFF, 0x00, 0x00)),
                                Triple("Green", Color(0xFF49D68A), Triple(0x00, 0xFF, 0x00)),
                                Triple("Blue", Color(0xFF4F8BE0), Triple(0x00, 0x00, 0xFF)),
                                Triple("Purple", AccentA, Triple(0x8E, 0x7C, 0xF0)),
                                Triple("Cyan", Color(0xFF3FD4D4), Triple(0x00, 0xFF, 0xFF)),
                                Triple("White", Color(0xFFEDEDED), Triple(0xFF, 0xFF, 0xFF))
                            )
                            GlassCard {
                                Column(Modifier.padding(16.dp)) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                                        colours.forEach { (name, swatch, rgb) ->
                                            Box(
                                                Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(14.dp)).background(swatch)
                                                    .clickable {
                                                        val (r, g, b) = rgb
                                                        fireCmd("Colour $name", 0x03, 0x82, byteArrayOf(r.toByte(), g.toByte(), b.toByte()))
                                                    }
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text("Sends RGB to reg 0x82 — byte format unconfirmed", fontSize = 10.sp, color = TextDim)
                                }
                            }
                        }
                        item { Text("Action buttons are unconfirmed — in G2 mode they require a successful Handshake.", fontSize = 10.sp, color = TextDim, modifier = Modifier.padding(4.dp)) }
                        item { Spacer(Modifier.height(8.dp)) }
                    }
                    1 -> {
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                MetricRing("Speed, km/h", telemetry["speed"] ?: "—", (telemetry["speed"]?.toFloatOrNull() ?: 0f) / 25f, AccentA, Modifier.weight(1f))
                                MetricRing("Battery, %", telemetry["battery"] ?: "—", (telemetry["battery"]?.toFloatOrNull() ?: 0f) / 100f, Green, Modifier.weight(1f))
                            }
                        }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                BigCard("📏", "Odometer", telemetry["odo"] ?: "—", Modifier.weight(1f))
                                BigCard("🧭", "Range", telemetry["range"] ?: "—", Modifier.weight(1f))
                            }
                        }
                        item { GradientButton("Refresh telemetry", "⟳", modifier = Modifier.fillMaxWidth()) { poll() } }
                        item {
                            GlassCard {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    if (!encMode) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            RadioButton(selected = proto == 1, onClick = { proto = 1 },
                                                colors = RadioButtonDefaults.colors(selectedColor = AccentA)); Text("55 AA", color = Color.White)
                                            Spacer(Modifier.width(14.dp))
                                            RadioButton(selected = proto == 2, onClick = { proto = 2 },
                                                colors = RadioButtonDefaults.colors(selectedColor = AccentA)); Text("5A A5", color = Color.White)
                                        }
                                    }
                                    OutlinedTextField(
                                        value = target, onValueChange = { target = it.take(2) },
                                        label = { Text("Board (hex)") }, singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = AccentA, unfocusedBorderColor = Stroke1,
                                            focusedTextColor = Color.White, unfocusedTextColor = Color.White
                                        ),
                                        modifier = Modifier.width(160.dp)
                                    )
                                }
                            }
                        }
                        item { Spacer(Modifier.height(8.dp)) }
                    }
                    2 -> {
                        item { SectionTitle("Quick commands · unconfirmed") }
                        run {
                            // name, emoji, cmd, index, data bytes (empty = read request with size 1)
                            data class Cmd(val emoji: String, val name: String, val cmd: Int, val idx: Int, val data: ByteArray, val write: Boolean)
                            val cmds = listOf(
                                Cmd("🔓", "Unlock", 0x03, 0x05, byteArrayOf(0x01), true),
                                Cmd("🔒", "Lock", 0x03, 0x15, byteArrayOf(0x01), true),
                                Cmd("🔧", "Device info", 0x01, 0x31, byteArrayOf(0x20), false),
                                Cmd("🛴", "Scooter info", 0x01, 0x60, byteArrayOf(0x20), false),
                                Cmd("📈", "Realtime", 0x01, 0x63, byteArrayOf(0x20), false),
                                Cmd("🔋", "Battery cover", 0x03, 0xC0, byteArrayOf(0x01), true),
                                Cmd("💡", "Light on", 0x03, 0x61, byteArrayOf(0x01), true),
                                Cmd("🌙", "Light off", 0x03, 0x61, byteArrayOf(0x00), true),
                                Cmd("🔊", "Sound 1", 0x03, 0xA2, byteArrayOf(0x01), true),
                                Cmd("📢", "Sound 4", 0x03, 0xA2, byteArrayOf(0x04), true),
                                Cmd("ℹ️", "Firmware", 0x01, 0xFA, byteArrayOf(0x14), false),
                                Cmd("🔄", "IoT restart", 0x03, 0x92, byteArrayOf(0x01), true),
                                Cmd("📡", "IoT config", 0x01, 0x31, byteArrayOf(0x20), false),
                                Cmd("🏷", "Read RFID", 0x01, 0x85, byteArrayOf(0x08), false),
                                Cmd("🎨", "Colour", 0x03, 0x82, byteArrayOf(0x01), true),
                                Cmd("📶", "Next SIM", 0x03, 0xC6, byteArrayOf(0x01), true),
                                Cmd("✅", "Update cert", 0x03, 0xC4, byteArrayOf(0x01), true)
                            )
                            val t = target.toIntOrNull(16) ?: 1
                            fun fire(c: Cmd) {
                                logs.add(0, "CMD ${c.name}: board=0x%02X cmd=0x%02X idx=0x%02X data=%s".format(t, c.cmd, c.idx, Nb.hex(c.data)))
                                if (encMode) {
                                    val key = session.key; val auth = session.auth
                                    if (key == null || auth == null) { logs.add(0, "No session — do the handshake first"); return }
                                    session.counter++
                                    sendWire(NbCrypto.encryptSn(key, auth, session.counter, Nb.buildEncPlain(t, c.cmd, c.idx, c.data)))
                                } else {
                                    ble.send(if (proto == 1) Nb.buildP1(t, c.cmd, c.idx, c.data) else Nb.buildP2(t, c.cmd, c.idx, c.data))
                                }
                            }
                            items(cmds.chunked(2)) { row ->
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    row.forEach { c ->
                                        val border = if (c.write) Red.copy(alpha = 0.4f) else Stroke1
                                        Surface(
                                            shape = RoundedCornerShape(20.dp), color = CardBg, border = BorderStroke(1.dp, border),
                                            modifier = Modifier.weight(1f).clickable { fire(c) }
                                        ) {
                                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                                IconBubble(c.emoji, 38)
                                                Spacer(Modifier.width(10.dp))
                                                Column {
                                                    Text(c.name, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.White)
                                                    Text("0x%02X".format(c.idx), fontSize = 11.sp, color = TextDim)
                                                }
                                            }
                                        }
                                    }
                                    if (row.size == 1) Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                        item { Text("Red border = write command (action), unconfirmed — may not work or may change the wrong setting.", fontSize = 10.sp, color = TextDim, modifier = Modifier.padding(4.dp)) }
                        item { SectionTitle("Send raw frame") }
                        item {
                            var rCmd by remember { mutableStateOf("01") }
                            var rIndex by remember { mutableStateOf("26") }
                            var rData by remember { mutableStateOf("02") }
                            GlassCard {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    val fieldColors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = AccentA, unfocusedBorderColor = Stroke1,
                                        focusedTextColor = Color.White, unfocusedTextColor = Color.White
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(value = target, onValueChange = { target = it.take(2) },
                                            label = { Text("Board") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
                                        OutlinedTextField(value = rCmd, onValueChange = { rCmd = it.take(2) },
                                            label = { Text("CMD") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
                                        OutlinedTextField(value = rIndex, onValueChange = { rIndex = it.take(2) },
                                            label = { Text("INDEX") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
                                    }
                                    OutlinedTextField(value = rData, onValueChange = { rData = it }, label = { Text("DATA (hex, space-separated)") },
                                        singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                                    GradientButton("Send", "➤", modifier = Modifier.fillMaxWidth()) {
                                        val t = target.toIntOrNull(16) ?: 1
                                        val cmd = rCmd.toIntOrNull(16) ?: 1
                                        val idx = rIndex.toIntOrNull(16) ?: 0
                                        val data = rData.trim().split(" ", ",").filter { it.isNotBlank() }
                                            .mapNotNull { it.toIntOrNull(16) }.map { it.toByte() }.toByteArray()
                                        if (encMode) {
                                            val key = session.key; val auth = session.auth
                                            if (key == null || auth == null) { logs.add(0, "No session — do the handshake first"); return@GradientButton }
                                            session.counter++
                                            sendWire(NbCrypto.encryptSn(key, auth, session.counter, Nb.buildEncPlain(t, cmd, idx, data)))
                                        } else {
                                            ble.send(if (proto == 1) Nb.buildP1(t, cmd, idx, data) else Nb.buildP2(t, cmd, idx, data))
                                        }
                                    }
                                }
                            }
                        }
                        item { SectionTitle("Log") }
                        itemsIndexed(logs) { i, line ->
                            if (LITE_MODE) {
                                Text(line, fontSize = 11.sp, color = TextDim, modifier = Modifier.padding(vertical = 2.dp))
                            } else {
                                var shown by remember(line, i) { mutableStateOf(i != 0) }
                                LaunchedEffect(line, i) { if (i == 0) shown = true }
                                AnimatedVisibility(visible = shown, enter = fadeIn(tween(220)) + slideInHorizontally(tween(220)) { -it / 6 }) {
                                    Text(line, fontSize = 11.sp, color = TextDim, modifier = Modifier.padding(vertical = 2.dp))
                                }
                            }
                        }
                        item { Spacer(Modifier.height(16.dp)) }
                    }
                    else -> {
                        item { SectionTitle("Scan") }
                        item {
                            GlassCard {
                                Column {
                                    SettingSwitch("Show all BLE devices", "Disable the Segway filter", showAllBt) { showAllBt = it }
                                    HorizontalDivider(color = Stroke1)
                                    SettingSwitch("Debug log", "Show raw scan / RX log", debugLog) { debugLog = it }
                                }
                            }
                        }
                        item { SectionTitle("Auto-reconnect") }
                        item {
                            GlassCard {
                                Column {
                                    SettingSwitch("Enable", "Reconnect after an unexpected drop", autoReconnect) { autoReconnect = it }
                                    HorizontalDivider(color = Stroke1)
                                    SettingStepper("Max attempts", maxAttempts, 1, 99, 1) { maxAttempts = it }
                                    HorizontalDivider(color = Stroke1)
                                    SettingStepper("Delay (ms)", reconnectDelay, 100, 5000, 50) { reconnectDelay = it }
                                }
                            }
                        }
                        item { SectionTitle("Device") }
                        item {
                            GlassCard {
                                Column {
                                    SettingStepper("Device type", deviceType, 0, 20, 1) { deviceType = it }
                                }
                            }
                        }
                        item { Text("Auto-reconnect re-establishes the BLE link to your own scooter if it drops. It does not resend any action commands.", fontSize = 10.sp, color = TextDim, modifier = Modifier.padding(8.dp)) }
                        item { Spacer(Modifier.height(16.dp)) }
                    }
                }
            }
            }
        }
    }
}
