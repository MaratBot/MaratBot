package com.example.g30

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Bg = Color(0xFF0F0D17)
private val CardBg = Color(0xFF1B1826)
private val Accent = Color(0xFF7B68E6)
private val AccentDark = Color(0xFF26223F)
private val Green = Color(0xFF55C486)
private val Amber = Color(0xFFE0A030)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, background = Bg, surface = CardBg,
                    onSurface = Color.White, onBackground = Color.White,
                    secondaryContainer = AccentDark, onSecondaryContainer = Color.White
                )
            ) { Screen() }
        }
    }
}

@Composable
fun Chip(text: String, dot: Color) {
    Surface(shape = RoundedCornerShape(50), color = AccentDark) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.width(8.dp))
            Text(text, fontSize = 15.sp)
        }
    }
}

@Composable
fun SectionTitle(t: String) = Text(t, fontSize = 15.sp, color = Color(0xFFA9A4BF), modifier = Modifier.padding(top = 8.dp, start = 4.dp))

@Composable
fun BigCard(emoji: String, title: String, value: String, modifier: Modifier = Modifier) {
    Surface(shape = RoundedCornerShape(24.dp), color = CardBg, modifier = modifier) {
        Column(Modifier.padding(18.dp)) {
            Box(Modifier.size(48.dp).clip(CircleShape).background(AccentDark), contentAlignment = Alignment.Center) {
                Text(emoji, fontSize = 22.sp)
            }
            Spacer(Modifier.height(12.dp))
            Text(title, color = Color(0xFFA9A4BF), fontSize = 14.sp)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun Screen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val main = remember { Handler(Looper.getMainLooper()) }
    val logs = remember { mutableStateListOf<String>() }
    val devices = remember { mutableStateListOf<Pair<BluetoothDevice, String>>() }
    val telemetry = remember { mutableStateMapOf<String, String>() }
    val rx = remember { ArrayList<Byte>() }
    var state by remember { mutableStateOf("Не подключено") }
    var proto by remember { mutableIntStateOf(2) }
    var target by remember { mutableStateOf("01") }
    var tab by remember { mutableIntStateOf(0) }
    var encMode by remember { mutableStateOf(true) }
    var sessionState by remember { mutableStateOf("Сессии нет") }
    var deviceNameSel by remember { mutableStateOf("") }
    val session = remember { NbSession() }
    val bleBox = remember { arrayOfNulls<BleClient>(1) }

    fun sendWire(w: ByteArray) { bleBox[0]?.send(w) }

    fun handleEncFrame(raw: ByteArray) {
        val key = session.key
        if (key == null) { logs.add(0, "Нет ключа для расшифровки"); return }
        val plain = NbCrypto.decrypt(key, session.auth ?: ByteArray(16), raw)
        if (plain == null || plain.size < 6) { logs.add(0, "Не удалось расшифровать кадр"); return }
        val board = plain[3].toInt() and 0xFF
        val cmd = plain[4].toInt() and 0xFF
        val index = plain[5].toInt() and 0xFF
        val data = plain.copyOfRange(6, plain.size)
        logs.add(0, "ENC RX: board=%02X cmd=%02X idx=%02X data=%s".format(board, cmd, index, Nb.hex(data)))
        when (cmd) {
            0x5B -> {
                if (data.size >= 30) {
                    val auth = data.copyOfRange(0, 16)
                    val serial = data.copyOfRange(16, 30)
                    session.auth = auth; session.serial = serial; session.counter = 1
                    sessionState = "Есть auth+SN, отправляю пароль"
                    val pwd = NbCrypto.generatePassword(auth)
                    session.password = pwd
                    session.key = NbCrypto.deriveKey(deviceNameSel.toByteArray(), auth)
                    session.counter++
                    val p = Nb.buildEncPlain(0x04, 0x5C, 0x00, pwd)
                    sendWire(NbCrypto.encryptSn(session.key!!, auth, session.counter, p))
                } else { sessionState = "PRE_COMM: неожиданный ответ"; logs.add(0, "Похоже на эхо или не тот формат") }
            }
            0x5C -> {
                if (index == 1) {
                    sessionState = "Пароль принят, авторизация…"
                    val auth = session.auth!!
                    session.key = NbCrypto.deriveKey(session.password!!, auth)
                    session.counter++
                    val p = Nb.buildEncPlain(0x04, 0x5D, 0x00, session.serial!!)
                    sendWire(NbCrypto.encryptSn(session.key!!, auth, session.counter, p))
                } else {
                    sessionState = "Нужно нажать кнопку на самокате, затем ещё раз «Рукопожатие»"
                }
            }
            0x5D -> {
                sessionState = if (index == 1) "Подключено (COMM)" else "Авторизация не удалась"
            }
            else -> {
                when {
                    index == 0x26 && data.size >= 2 -> telemetry["speed"] = "%.1f км/ч".format(Nb.le(data) / 10.0)
                    index == 0xB5 && data.size >= 2 -> telemetry["battery"] = "${Nb.le(data)} %"
                    index == 0xB7 && data.size >= 4 -> telemetry["odo"] = "%.3f км".format(Nb.le(data) / 1000.0)
                    index == 0x25 && data.size >= 2 -> telemetry["range"] = "%.1f км".format(Nb.le(data) / 10.0)
                }
            }
        }
    }

    fun sendEncRead(targetBoard: Int, index: Int, size: Int) {
        val key = session.key; val auth = session.auth
        if (key == null || auth == null) { logs.add(0, "Сначала выполните рукопожатие"); return }
        session.counter++
        val p = Nb.buildEncPlain(targetBoard, 0x01, index, byteArrayOf(size.toByte()))
        sendWire(NbCrypto.encryptSn(key, auth, session.counter, p))
    }

    fun doHandshake() {
        if (deviceNameSel.isEmpty()) { logs.add(0, "Сначала подключитесь к самокату"); return }
        session.auth = null; session.serial = null; session.password = null; session.counter = 0
        sessionState = "PRE_COMM…"
        val key = NbCrypto.deriveKey(deviceNameSel.toByteArray(), null)
        session.key = key
        val p = Nb.buildEncPlain(0x04, 0x5B, 0x00, ByteArray(0))
        sendWire(NbCrypto.encryptNonSn(key, p))
    }

    val ble = remember {
        BleClient(ctx, object : BleClient.Listener {
            override fun log(s: String) { main.post { logs.add(0, s) } }
            override fun state(s: String) { main.post { state = s } }
            override fun found(d: BluetoothDevice, name: String) {
                main.post {
                    if (name.isNotEmpty() && devices.none { it.first.address == d.address }) devices.add(d to name)
                }
            }
            override fun data(b: ByteArray) {
                main.post {
                    logs.add(0, "RX: " + Nb.hex(b))
                    b.forEach { rx.add(it) }
                    if (encMode) {
                        while (true) { val f = Nb.extractEncFrame(rx) ?: break; handleEncFrame(f) }
                    } else {
                        for (f in Nb.parse(rx)) {
                            logs.add(0, "Кадр: board=%02X cmd=%02X idx=%02X data=%s".format(f.target, f.cmd, f.index, Nb.hex(f.data)))
                            when {
                                f.index == 0x26 && f.data.size >= 2 -> telemetry["speed"] = "%.1f км/ч".format(Nb.le(f.data) / 10.0)
                                f.index == 0xB5 && f.data.size >= 2 -> telemetry["battery"] = "${Nb.le(f.data)} %"
                                f.index == 0xB7 && f.data.size >= 4 -> telemetry["odo"] = "%.3f км".format(Nb.le(f.data) / 1000.0)
                                f.index == 0x25 && f.data.size >= 2 -> telemetry["range"] = "%.1f км".format(Nb.le(f.data) / 10.0)
                            }
                        }
                    }
                }
            }
        })
    }
    bleBox[0] = ble

    val perms = if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) { devices.clear(); ble.scan() } else state = "Нет разрешений"
    }

    fun poll() {
        val t = target.toIntOrNull(16) ?: 1
        scope.launch {
            for ((idx, size) in listOf(0x26 to 2, 0xB5 to 2, 0xB7 to 4, 0x25 to 2)) {
                if (encMode) sendEncRead(t, idx, size) else ble.send(Nb.readRequest(proto, t, idx, size))
                delay(500)
            }
        }
    }

    val connected = state == "Подключено"

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = CardBg) {
                listOf("⚡ Управление", "🏎 Телеметрия", "⌨ Консоль").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Text(label.substringBefore(" "), fontSize = 20.sp) },
                        label = { Text(label.substringAfter(" "), fontSize = 12.sp) })
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).statusBarsPadding().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(when (tab) { 0 -> "Управление"; 1 -> "Телеметрия"; else -> "Консоль" }, fontSize = 30.sp, modifier = Modifier.padding(vertical = 12.dp))

            when (tab) {
                0 -> {
                    Surface(shape = RoundedCornerShape(28.dp), color = CardBg) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Ninebot G2", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Chip(state, if (connected) Green else Amber)
                                Chip(sessionState, if (sessionState == "Подключено (COMM)") Green else Amber)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(onClick = { launcher.launch(perms) }, modifier = Modifier.weight(1f).height(52.dp),
                                    shape = RoundedCornerShape(26.dp)) { Text("Поиск") }
                                FilledTonalButton(onClick = { ble.disconnect(); sessionState = "Сессии нет" }, modifier = Modifier.weight(1f).height(52.dp),
                                    shape = RoundedCornerShape(26.dp)) { Text("Отключить") }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(checked = encMode, onCheckedChange = { encMode = it })
                                Spacer(Modifier.width(8.dp))
                                Text("Шифрование (G2)", fontSize = 14.sp)
                            }
                            Button(onClick = { doHandshake() }, enabled = connected,
                                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp)) {
                                Text("🤝  Рукопожатие")
                            }
                        }
                    }
                    if (devices.isNotEmpty() && !connected) {
                        SectionTitle("Найденные устройства")
                        LazyColumn(Modifier.heightIn(max = 160.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(devices) { (d, n) ->
                                Surface(shape = RoundedCornerShape(16.dp), color = CardBg, modifier = Modifier.fillMaxWidth()
                                    .clickable { deviceNameSel = n; ble.connect(d) }) {
                                    Text("$n   ${d.address}", Modifier.padding(14.dp))
                                }
                            }
                        }
                    }
                    SectionTitle("Блокировка")
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(onClick = { logs.add(0, "Unlock: регистр для G2 ещё не подтверждён") },
                            modifier = Modifier.weight(1f).height(64.dp), shape = RoundedCornerShape(32.dp)) { Text("🔓  Unlock", fontSize = 17.sp) }
                        FilledTonalButton(onClick = { logs.add(0, "Lock: регистр для G2 ещё не подтверждён") },
                            modifier = Modifier.weight(1f).height(64.dp), shape = RoundedCornerShape(32.dp)) { Text("🔒  Lock", fontSize = 17.sp) }
                    }
                    SectionTitle("Аксессуары")
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        BigCard("🔋", "Заряд", telemetry["battery"] ?: "—", Modifier.weight(1f))
                        Surface(shape = RoundedCornerShape(24.dp), color = CardBg, modifier = Modifier.weight(1f)
                            .clickable { logs.add(0, "Фара: регистр для G2 ещё не подтверждён") }) {
                            Column(Modifier.padding(18.dp)) {
                                Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0xFF3A3020)), contentAlignment = Alignment.Center) { Text("💡", fontSize = 22.sp) }
                                Spacer(Modifier.height(12.dp))
                                Text("Фара", color = Color(0xFFA9A4BF), fontSize = 14.sp)
                                Text("скоро", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
                1 -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        BigCard("🏎", "Скорость", telemetry["speed"] ?: "—", Modifier.weight(1f))
                        BigCard("🔋", "Заряд", telemetry["battery"] ?: "—", Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        BigCard("📏", "Пробег", telemetry["odo"] ?: "—", Modifier.weight(1f))
                        BigCard("🧭", "Запас хода", telemetry["range"] ?: "—", Modifier.weight(1f))
                    }
                    Button(onClick = { poll() }, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(28.dp)) {
                        Text("Обновить")
                    }
                    if (!encMode) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = proto == 1, onClick = { proto = 1 }); Text("55 AA")
                            Spacer(Modifier.width(10.dp))
                            RadioButton(selected = proto == 2, onClick = { proto = 2 }); Text("5A A5")
                        }
                    }
                    OutlinedTextField(value = target, onValueChange = { target = it.take(2) }, label = { Text("Плата (hex)") },
                        singleLine = true, modifier = Modifier.width(140.dp))
                }
                else -> {
                    SectionTitle("Быстрые команды (чтение, DIS board)")
                    val quick = listOf(
                        Triple("🔋", "Battery %", 0xB5 to 2),
                        Triple("🏎", "Speed", 0x26 to 2),
                        Triple("📏", "Odometer", 0xB7 to 4),
                        Triple("🧭", "Range", 0x25 to 2),
                        Triple("⚙️", "Riding mode", 0x74 to 2),
                        Triple("🔊", "Volume", 0x75 to 2),
                        Triple("💡", "Headlight brightness", 0x7B to 1),
                        Triple("🆔", "Serial number", 0x10 to 14)
                    )
                    val t = target.toIntOrNull(16) ?: 1
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 340.dp)) {
                        items(quick.chunked(2)) { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                row.forEach { (emoji, name, reg) ->
                                    val (idx, size) = reg
                                    Surface(shape = RoundedCornerShape(20.dp), color = CardBg, modifier = Modifier.weight(1f)
                                        .clickable { if (encMode) sendEncRead(t, idx, size) else ble.send(Nb.readRequest(proto, t, idx, size)) }) {
                                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Box(Modifier.size(40.dp).clip(CircleShape).background(AccentDark), contentAlignment = Alignment.Center) { Text(emoji, fontSize = 18.sp) }
                                            Spacer(Modifier.width(10.dp))
                                            Column {
                                                Text(name, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                                Text("0x%02X".format(idx), fontSize = 12.sp, color = Color(0xFFA9A4BF))
                                            }
                                        }
                                    }
                                }
                                if (row.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                    SectionTitle("Журнал")
                    LazyColumn(Modifier.weight(1f)) { items(logs) { Text(it, fontSize = 11.sp, modifier = Modifier.padding(vertical = 2.dp)) } }
                }
            }
        }
    }
}
