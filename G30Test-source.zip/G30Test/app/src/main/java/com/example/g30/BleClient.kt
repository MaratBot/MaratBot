package com.example.g30

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import java.util.UUID

@SuppressLint("MissingPermission")
class BleClient(private val ctx: Context, private val ui: Listener) {
    interface Listener {
        fun log(s: String)
        fun state(s: String)
        fun data(b: ByteArray)
        fun found(d: BluetoothDevice, name: String)
    }

    companion object {
        val SERVICE: UUID = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
        val WRITE: UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e")
        val NOTIFY: UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    private val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var gatt: BluetoothGatt? = null
    private var tx: BluetoothGattCharacteristic? = null

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            ui.found(r.device, r.scanRecord?.deviceName ?: r.device.name ?: "")
        }
    }

    fun scan() { adapter.bluetoothLeScanner?.startScan(scanCb); ui.state("Поиск…") }
    fun stopScan() { adapter.bluetoothLeScanner?.stopScan(scanCb) }

    fun connect(d: BluetoothDevice) {
        stopScan()
        ui.state("Подключение…")
        gatt = d.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
    }

    fun disconnect() { gatt?.disconnect(); gatt?.close(); gatt = null; tx = null; ui.state("Не подключено") }

    fun send(b: ByteArray) {
        val g = gatt; val c = tx
        if (g == null || c == null) { ui.log("Нет подключения"); return }
        ui.log("TX: " + Nb.hex(b))
        if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(c, b, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
        } else {
            @Suppress("DEPRECATION") run { c.value = b; g.writeCharacteristic(c) }
        }
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) { ui.log("Связь есть, запрашиваю MTU"); g.requestMtu(247) }
            else { ui.state("Отключено (status=$status)"); g.close() }
        }
        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) { g.discoverServices() }
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            ui.log("Сервисы: " + g.services.joinToString { it.uuid.toString().take(8) })
            val s = g.getService(SERVICE)
            if (s == null) { ui.state("Сервис UART не найден"); return }
            tx = s.getCharacteristic(WRITE)
            val n = s.getCharacteristic(NOTIFY)
            if (tx == null || n == null) { ui.state("Нет нужных характеристик"); return }
            g.setCharacteristicNotification(n, true)
            val d = n.getDescriptor(CCCD)
            if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
            else @Suppress("DEPRECATION") run { d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; g.writeDescriptor(d) }
            ui.state("Подключено")
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            ui.data(value)
        }
        @Suppress("DEPRECATION")
        @Deprecated("old API")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT < 33) ui.data(c.value)
        }
    }
}
