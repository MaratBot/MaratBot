package com.example.g30

import android.content.Context
import android.content.SharedPreferences

/**
 * 4 BLE-ключа, которые пользователь записал в самокат.
 * Каждый ключ проверяется по формату (hex 16/32/64).
 */
data class BleKeys(
    val key1: String = "",
    val key2: String = "",
    val key3: String = "",
    val key4: String = ""
) {
    fun list() = listOf(key1, key2, key3, key4)
    fun isComplete() = list().all { it.isNotBlank() }
    fun allValid() = list().all { isValidFormat(it) }

    companion object {
        fun isValidFormat(key: String): Boolean {
            val c = key.trim().replace(" ", "").replace(":", "").lowercase()
            if (c.isEmpty()) return false
            if (c.length !in listOf(16, 32, 64)) return false
            return c.all { it in "0123456789abcdef" }
        }

        fun toBytes(key: String): ByteArray {
            val c = key.trim().replace(" ", "").replace(":", "")
            return c.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        }
    }
}

enum class KeyCheck { Empty, InvalidFormat, Ok }

class BleKeysStore(ctx: Context) {
    private val prefs: SharedPreferences =
        ctx.getSharedPreferences("maratbot_ble_keys", Context.MODE_PRIVATE)

    fun load(): BleKeys = BleKeys(
        key1 = prefs.getString("k1", "") ?: "",
        key2 = prefs.getString("k2", "") ?: "",
        key3 = prefs.getString("k3", "") ?: "",
        key4 = prefs.getString("k4", "") ?: ""
    )

    fun save(keys: BleKeys) {
        prefs.edit()
            .putString("k1", keys.key1.trim())
            .putString("k2", keys.key2.trim())
            .putString("k3", keys.key3.trim())
            .putString("k4", keys.key4.trim())
            .apply()
    }

    fun check(key: String): KeyCheck = when {
        key.isBlank() -> KeyCheck.Empty
        !BleKeys.isValidFormat(key) -> KeyCheck.InvalidFormat
        else -> KeyCheck.Ok
    }
}
