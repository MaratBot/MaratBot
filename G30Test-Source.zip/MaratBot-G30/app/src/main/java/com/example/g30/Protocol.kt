package com.example.g30

class Frame(val proto: Int, val target: Int, val cmd: Int, val index: Int, val data: ByteArray)

object Nb {
    const val CMD_READ = 0x01
    const val CMD_WRITE = 0x02

    /** Protocol 1: 55 AA LEN TARGET CMD INDEX DATA.. CRC_LO CRC_HI (LEN = data+2) */
    fun buildP1(target: Int, cmd: Int, index: Int, data: ByteArray): ByteArray {
        val body = byteArrayOf((data.size + 2).toByte(), target.toByte(), cmd.toByte(), index.toByte()) + data
        val crc = body.sumOf { it.toInt() and 0xFF }.inv() and 0xFFFF
        return byteArrayOf(0x55, 0xAA.toByte()) + body + byteArrayOf((crc and 0xFF).toByte(), (crc shr 8).toByte())
    }

    /** Protocol 2 (per docs): 5A A5 LEN 3E TARGET CMD INDEX DATA.. CRC_LO CRC_HI (LEN = data) */
    fun buildP2(target: Int, cmd: Int, index: Int, data: ByteArray): ByteArray {
        val body = byteArrayOf(data.size.toByte(), 0x3E, target.toByte(), cmd.toByte(), index.toByte()) + data
        val crc = body.sumOf { it.toInt() and 0xFF }.inv() and 0x7FFF
        return byteArrayOf(0x5A, 0xA5.toByte()) + body + byteArrayOf((crc and 0xFF).toByte(), (crc shr 8).toByte())
    }

    fun parse(buf: ByteArray): List<Frame> {
        val out = ArrayList<Frame>()
        var i = 0
        while (i + 6 < buf.size) {
            val b0 = buf[i].toInt() and 0xFF
            val b1 = buf[i + 1].toInt() and 0xFF
            val p1 = b0 == 0x55 && b1 == 0xAA
            val p2 = b0 == 0x5A && b1 == 0xA5
            if (!p1 && !p2) { i++; continue }
            val len = buf[i + 2].toInt() and 0xFF
            val total = if (p1) len + 4 else len + 6
            if (i + total > buf.size) break
            val f = buf.copyOfRange(i, i + total)
            i += total
            fun u(idx: Int) = f[idx].toInt() and 0xFF
            out += if (p1) Frame(1, u(3), u(4), u(5), f.copyOfRange(6, 6 + len - 2))
            else Frame(2, u(4), u(5), u(6), f.copyOfRange(7, 7 + len))
        }
        return out
    }

    fun le(d: ByteArray): Long {
        var v = 0L
        for (i in d.indices.reversed()) v = (v shl 8) or (d[i].toLong() and 0xFF)
        return v
    }

    fun hex(b: ByteArray) = b.joinToString(" ") { "%02X".format(it) }

    /** Plaintext Encryption2 frame (before encryption): 5A A5 LEN 3E TARGET CMD INDEX DATA.. */
    fun buildEncPlain(target: Int, cmd: Int, index: Int, data: ByteArray): ByteArray {
        val len = data.size
        return byteArrayOf(0x5A, 0xA5.toByte(), len.toByte(), 0x3E, target.toByte(), cmd.toByte(), index.toByte()) + data
    }

    /** Extracts one full encrypted frame (5A A5 LEN .. +13) from the buffer once it has fully arrived. */
    fun extractEncFrame(buf: ArrayList<Byte>): ByteArray? {
        var i = 0
        while (i + 1 < buf.size) {
            val a = buf[i].toInt() and 0xFF; val b = buf[i + 1].toInt() and 0xFF
            if (a == 0x5A && b == 0xA5) break
            i++
        }
        repeat(i) { buf.removeAt(0) }
        if (buf.size < 3) return null
        val len = buf[2].toInt() and 0xFF
        val total = len + 13
        if (buf.size < total) return null
        val f = ByteArray(total) { buf[it] }
        repeat(total) { buf.removeAt(0) }
        return f
    }

    // ---- Control helpers for Ninebot Max G30 ----
    // Индексы могут отличаться на разных прошивках — при необходимости подправь.

    fun buildSpeedLimit(kmh: Int, useP2: Boolean = true): ByteArray {
        val v = kmh.coerceIn(5, 40).toByte()
        return if (useP2) buildP2(0x20, CMD_WRITE, 0x04, byteArrayOf(v))
        else buildP1(0x20, CMD_WRITE, 0x04, byteArrayOf(v))
    }

    fun buildLock(useP2: Boolean = true): ByteArray {
        return if (useP2) buildP2(0x20, CMD_WRITE, 0x50, byteArrayOf(0x01))
        else buildP1(0x20, CMD_WRITE, 0x50, byteArrayOf(0x01))
    }

    fun buildUnlock(useP2: Boolean = true): ByteArray {
        return if (useP2) buildP2(0x20, CMD_WRITE, 0x50, byteArrayOf(0x00))
        else buildP1(0x20, CMD_WRITE, 0x50, byteArrayOf(0x00))
    }

    fun buildHeadlight(on: Boolean, useP2: Boolean = true): ByteArray {
        val v = if (on) 0x01.toByte() else 0x00.toByte()
        return if (useP2) buildP2(0x20, CMD_WRITE, 0x10, byteArrayOf(v))
        else buildP1(0x20, CMD_WRITE, 0x10, byteArrayOf(v))
    }
}
