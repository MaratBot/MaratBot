MaratBot 1.0.0 (By кверти)

MaratBot G30 — управление Ninebot Max G30 (не шеринг)

Что добавлено:
1) Вкладка «Keys» — 4 BLE-ключа
   - ввод каждого ключа
   - проверка формата (hex 16/32/64) отдельно
   - сохранение
   - кнопка «В handshake» — использовать ключ при авторизации

2) Команды управления
   - Lock / Unlock
   - Speed limit (5–40 км/ч)
   - Light on/off, Find/horn (как было)

3) Handshake
   - сначала customKey
   - иначе первый валидный из 4 ключей
   - иначе имя устройства

Сборка:
1. Открой папку MaratBot-G30 в Android Studio
2. Дождись Gradle Sync
3. Build > Build APK(s)
4. APK: app/build/outputs/apk/debug/app-debug.apk

Индексы команд ESC (0x04 speed, 0x50 lock, 0x10 light) могут отличаться
на разных прошивках — смотри лог RX и при необходимости поправь Protocol.kt.
